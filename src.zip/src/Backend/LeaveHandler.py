from flask import request as rq
from flask import Blueprint,jsonify
import sqlite3 as sq
from datetime import datetime, date
from PathConfig import CompanyUserPath,CredentialsPath
#Now we use NotifManager (send , update, recieve notification)
from Notification import notifManager
leaveManager = Blueprint('Leave', __name__, url_prefix='/api')

class LeaveHandler:
    def __init__(self, compUser_path, cred_path):
        self.compUser_path = compUser_path
        self.cred_path = cred_path

    def _get_connection(self):
        conn = sq.connect(self.compUser_path)
        conn.execute("PRAGMA foreign_keys = ON;")
        cursor = conn.cursor()
        cursor.execute(f"ATTACH DATABASE '{self.cred_path}' AS cred_db")
        return conn, cursor

    def create_tables(self):
        conn, cursor = self._get_connection()
        query = """
        CREATE TABLE IF NOT EXISTS IncomingLeaves(
            Leaveid INTEGER PRIMARY KEY AUTOINCREMENT,
            auth_id INTEGER NOT NULL,
            name TEXT NOT NULL,
            employeeId TEXT NOT NULL,
            department TEXT,
            startdate TEXT not null,
            enddate TEXT not null,
            reason TEXT not null,
            status TEXT default 'Not reviewed.',
            dateSubmitted TEXT not null,
            FOREIGN KEY (employeeId) REFERENCES "user"(employeeId) ON DELETE CASCADE
        );
        """
        cursor.execute(query)

        query = """
        CREATE TABLE IF NOT EXISTS LiveLeaves(
            Leaveid INTEGER PRIMARY KEY,
            auth_id INTEGER NOT NULL,
            name TEXT NOT NULL,
            employeeId TEXT NOT NULL,
            department TEXT,
            startdate TEXT not null,
            enddate TEXT not null,
            reason TEXT not null,
            status TEXT not null,
            dateSubmitted TEXT not null,
            FOREIGN KEY (employeeId) REFERENCES user(employeeId) ON DELETE CASCADE
        );
        """
        cursor.execute(query)

        conn.commit()
        conn.close()
    def createLeaveRq(self,name,department,startdate,enddate,reason,dateSubmitted,empId,auth_id):
        
        try:
            conn,cursor = self._get_connection()

            query = """
            INSERT INTO IncomingLeaves(auth_id, name, employeeId, department,startdate, enddate, reason, dateSubmitted)
            VALUES (?,?,?,?,?,?,?,?);
            """     
            cursor.execute(query,(auth_id,name,empId,department,startdate,enddate,reason,dateSubmitted,))
            conn.commit()
            conn.close()
            return "success"
        except Exception as e:
            print("Error createLeaverq",e)
            return "error"
        finally:
            if conn:
                conn.close() 

    def fetchData(self,Leaveid):
        try:
            conn,cursor = self._get_connection()

            query = """
            select * from IncomingLeaves where Leaveid = ?;
            """     
            cursor.execute(query,(Leaveid,))
            res = cursor.fetchone()
            conn.close()    
            #print(res)
            return res
        except Exception as e:
            print("Error createLeaverq",e)
            return jsonify(e)
        finally:
            if conn:
                conn.close() 
    def LeavesChecker(self):
        conn, cursor = self._get_connection()
        today = date.today()

        cursor.execute("""
            SELECT Leaveid, enddate
            FROM LiveLeaves
            WHERE status = 'Active'
        """)

        activeLeaves = cursor.fetchall()
        closedCount = 0

        for leave in activeLeaves:
            leaveId = leave[0]
            enddate_str = leave[1]  # ← THIS is enddate_str

            enddate = datetime.strptime(enddate_str, "%Y-%m-%d").date()

            # 🔑 Rule: close if today is enddate OR passed
            if today >= enddate:
                #First update the column val to completed. IF time has passed.
                cursor.execute("""
                    UPDATE LiveLeaves
                    SET status = 'Completed'
                    WHERE Leaveid = ?
                """, (leaveId,))
                #Delete the col value IF time has passed.
                cursor.execute("""
                    delete from LiveLeaves
                    where status = 'Completed'
                    and Leaveid = ?
                """, (leaveId,))
                #Make sure to update attendance table.

                #First update status to 'Leave' where leaveDuration is not null. / Will be null.
                cursor.execute("""
                    UPDATE Attendance
                    SET status = 'Leave'
                    WHERE leaveDuration IS NOT NULL""")

                #NOW We use subquery to first GET employeeID THEN update set.
                cursor.execute("""update Attendance set leaveDuration = NULL 
                                  where empId = (select employeeId from LiveLeaves where Leaveid = ?) 
                """,(leaveId,))
                closedCount += 1

                #What happened:
                #1.Delete from live leaves where completed.
                #2.Update attendance set status to 'Leave' where leaveduration is not null. This will later help in dashboard fetch.
                #3.Update attendance set leaveduration to null where empId = employeeId from live
                #This way, the status is going to remain 'Leave' for that day, but leaveduration is null, so next time it won't be considered.

        conn.commit()
        conn.close()
        return closedCount
    
    def get_leave_count(self, empId, MonthYear):
        conn, cursor = self._get_connection()
        #This returns days which are flagged as leave from LeaveHandler.py
        fetchPaidDays = """
    SELECT count(*) FROM Attendance 
    WHERE empId = ? AND status = 'Leave' 
    AND date LIKE ?;
    """
        cursor.execute(fetchPaidDays, (empId, MonthYear + "%"))
        leave_days = cursor.fetchone()[0]
        conn.close()
        return leave_days
leavehandler = LeaveHandler(CompanyUserPath,CredentialsPath)

def createLeave():
    leavehandler.create_tables()

@leaveManager.route('/fetchAllRq/',methods=['GET'])
def FetchAllLeaves():
    try:
        conn, cursor = leavehandler._get_connection()
        allEmployeesQ = """
        select Leaveid, auth_id, name, employeeId, department, startdate, enddate, reason, dateSubmitted from IncomingLeaves;
        """
        cursor.execute(allEmployeesQ)
        fetchedEmployees = cursor.fetchall()

        result = []
        for r in fetchedEmployees:
            result.append({
                "Leaveid": r[0],
                "auth_id": r[1],
                "name": r[2],
                "employeeId": r[3],
                "department": r[4],
                "startdate": r[5],
                "enddate": r[6],
                "reason": r[7],
                "dateSubmitted": r[8]
            })
        conn.close()
        
        return jsonify(result) ,200
    except Exception as e:
        print(e)
        return jsonify({"status":"error"}) ,500
    finally:
        if conn:
            conn.close() 

@leaveManager.route('/postLeaveRq/<string:empId>/<string:auth_id>',methods=['POST'])
def PostLeave(empId,auth_id):
    data = rq.get_json()

    name = data.get('name')
    department = data.get('department')
    startdate = data.get('startDate')
    enddate = data.get('endDate')
    reason = data.get('reason')
    dateSubmitted = data.get('dateSubmitted')
    try:
        start = datetime.strptime(startdate, "%Y-%m-%d").date()
        end = datetime.strptime(enddate, "%Y-%m-%d").date()
        
        if reason == "":
            return jsonify({"message":"Reason not given. ","status":"reason not provided"})
        
        if end < start:
            return jsonify({"message":"Invalid structure. ","status":"datetime compare error"})

        status = leavehandler.createLeaveRq(auth_id=auth_id,name=name,department=department,startdate=startdate,enddate=enddate,reason=reason,dateSubmitted=dateSubmitted,empId=empId)
        notifManager.insert_notification(message=f"A leave request has been issued.",adminOnly=True)
        return jsonify({"message":"Leave request sent successfully.","status":status})
        
    except Exception as e:
        print(e)
        return jsonify({"message":f"{e}","status":"error"})
    
    #When leave application is created, store it in incomingLeaves (yet to accept). 
    

@leaveManager.route('/acceptLeave/<string:leaveID>',methods=['POST'])
def AcceptLeave(leaveID):
    #When leave application is accepted,
    #Remove from incomingLeaves
    #Transfer to LiveLeaves
    #Send notification.
    try:
        FetchedData = leavehandler.fetchData(leaveID)
        
        if not FetchedData:
            return jsonify({
                "message": "Leave request not found or already processed.",
                "status": "error"
            }), 404
        

        conn,cursor = leavehandler._get_connection()
        toLiveQuery = """
        INSERT OR IGNORE INTO LiveLeaves(
            LeaveId, auth_id, name, employeeId, department,
            startdate, enddate, reason, status, dateSubmitted
        ) VALUES (?,?,?,?,?,?,?,?,?,?)
        """
        cursor.execute(toLiveQuery,(FetchedData[0],FetchedData[1],FetchedData[2],FetchedData[3],FetchedData[4],FetchedData[5],FetchedData[6],FetchedData[7],'Active',FetchedData[9]))   
        remQuery = """
        delete from IncomingLeaves where LeaveId = ? and employeeId = ?;
        """
        conn.commit()
        cursor.execute(remQuery,(FetchedData[0],FetchedData[3]))
        conn.commit()

        #Update leaveDuration in attendance table for salary.
        ToEmpId = FetchedData[3]
        startDateObj = datetime.strptime(FetchedData[5], "%Y-%m-%d").date()
        endDateObj = datetime.strptime(FetchedData[6], "%Y-%m-%d").date()
        CompleteDuration = f"{startDateObj} to {endDateObj}"

        updateAttTable(conn,cursor,CompleteDuration,ToEmpId,startDateObj,endDateObj)

        conn.close()

        #Create notification for user and admin
        notifManager.insert_notification(employeeId=FetchedData[3],
                                         role=FetchedData[4],
                                         message=f"Your leave request from {FetchedData[5]} - {FetchedData[6]} has been approved.")
        notifManager.insert_notification(message=f"Leave req approved.",adminOnly=True)
        return jsonify({"message":"Leave request approved.","status":"success", "name": FetchedData[2]})
    except Exception as e:
        print(e)
        return jsonify({"message":f"{e}","status":"error"})
    finally:
        if conn:
            conn.close() # This runs even if the code crashes

@leaveManager.route('/rejectLeave/<string:leaveID>',methods=['POST'])
def RejectLeave(leaveID):
    #When leave application is rejected,
    #Remove from incomingLeaves.
    try:
        FetchedData = leavehandler.fetchData(leaveID)

        if not FetchedData:
            return jsonify({
                "message": "Leave request not found or already processed.",
                "status": "error"
            }), 404
        
        conn,cursor = leavehandler._get_connection()
        remQuery = """
        delete from IncomingLeaves where LeaveId = ? and employeeId = ?;
        """
        cursor.execute(remQuery,(FetchedData[0],FetchedData[3]))
        conn.commit()
        conn.close()
        notifManager.insert_notification(employeeId=FetchedData[3],
                                         role=FetchedData[4],
                                         message=f"Your leave request from {FetchedData[5]} - {FetchedData[6]} has been rejected.")
        notifManager.insert_notification(message=f"Leave req denied.",adminOnly=True)
        return jsonify({"message":"Leave request denied successfully.","status":"success","name": FetchedData[2]})
    except Exception as e:
        print(e)
        return jsonify({"message":f"{e}","status":"error"})
    finally:
        if conn:
            conn.close()

#This route will be called per refresh to see if a person's leave is finished / not.
@leaveManager.route('/CloseLeaveDuration/',methods=['GET'])
def CloseLeaveDuration():
    closedCount = leavehandler.LeavesChecker()
    return jsonify({"closedCount": closedCount}), 200

def updateAttTable(conn,cursor,CompleteDuration,ToEmpId,startDate,endDate):
    #We need employeeId, attendance table, start and end date.
    #Update set leaveduration to "start to end" where empId = employeeId
    attUpdateDurationQuery = """
    update Attendance set leaveDuration = ? where empId = ? and date between ? and ?
    """
    cursor.execute(attUpdateDurationQuery,(CompleteDuration,ToEmpId,startDate,endDate))
    conn.commit()